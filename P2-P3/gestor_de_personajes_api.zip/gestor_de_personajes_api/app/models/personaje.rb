class Personaje < ApplicationRecord
end
