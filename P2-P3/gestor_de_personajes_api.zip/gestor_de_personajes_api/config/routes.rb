Rails.application.routes.draw do
  resources :personajes, only: [:index, :create, :update, :destroy]
end
