Rails.application.routes.draw do
  resources :armaduras
  resources :personajes
end
