class ArmadurasController < ApplicationController
end
