class ArmaduraSerializer < ActiveModel::Serializer
    attributes :id, :tipo, :created_at, :updated_at
end
  