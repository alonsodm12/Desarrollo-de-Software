require "test_helper"

class ArmaduraTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
